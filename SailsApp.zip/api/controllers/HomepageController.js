/**
 * HomepageController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {
  

  /**
   * `HomepageController.formTest()`
   */
  addItem: async function (req, res) {
    return res.send('Item: ' + req.body.newItemValue);
  }

};

