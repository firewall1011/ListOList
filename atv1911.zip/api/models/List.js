/**
 * List.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {
    name: {
      type: 'string'
    },
    parent: {
      model: 'list'
    },
    // Add a reference to Items
    items: {
      collection: 'list',
      via: 'parent'
    },
    owner: {
      model: 'user'
    }
  },

};

