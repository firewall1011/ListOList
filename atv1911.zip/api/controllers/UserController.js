/**
 * UserController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {
  
    create_users: async function(req,res){
        var users=[
            {'name': 'John','age':20},
            {'name': 'Marye','age':42},
            {'name': 'Jonesy','age':33}
        ];
        try{
            var createdUsers = await User.createEach(users).fetch();
        } catch(err){
            sails.log(err.name);
            return res.json(' Record already exists');
        }
            sails.log(createdUsers);
            return res.json(createdUsers);
        },
    remove_users: async function(req,res){
        await User.destroy({});
        await Pet.destroy({});
        return res.json({});
    }

};

