/**
 * PetController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {
    create_pets: async function(req,res){
        try{
            var createdPets = await Pet.create({
                name: 'fido1', color: 'black', 
            }).fetch();
        } catch(err){
            sails.log(err);
            return res.json(' Record in Pets already exists');
        }
        sails.log(createdPets);
        return res.json(createdPets);
    },
    add_owners: async function(req,res){
        try{
            var coll = await Pet.addToCollection(3, 'owners', [7, 8]); /*sync com usuários*/
        } catch(err){
            sails.log(err);
            return res.json(' Error adding owners to collection');
        }
        sails.log(coll);
        return res.json(coll);
    },
    remove_owners: async function(req,res){
        try{
            var coll = await Pet.removeFromCollection(7, 'owners', [0, 1, 2]); /*sync com usuários*/
        } catch(err){
            sails.log(err);
            return res.json(' Error removing owners from collection');
        }
        sails.log(coll);
        return res.json(coll);
    }

};

